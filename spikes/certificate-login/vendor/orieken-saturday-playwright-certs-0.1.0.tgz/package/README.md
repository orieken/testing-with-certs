# @orieken/saturday-playwright-certs

A Saturday framework plugin to support running Playwright end-to-end browser tests against mTLS (mutual TLS) protected websites inside Docker containers using branded Google Chrome and Microsoft Edge.

## 🚀 Key Advantages

### Avoiding the Native Browser Certificate Picker
Normally, when a browser hits an mTLS-protected site, it displays a native operating system or browser-specific certificate picker popup. In an automated, headless, or unattended container environment (like CI), it is impossible to interact with this native modal. 

This plugin configures Playwright's native `clientCertificates` parameter. Playwright handles the client certificate handshake directly at the network layer during browser context initialization, **completely bypassing the browser's native certificate selection GUI**.

### Precise Origin Matching
Playwright requires that the client certificate `origin` match the target website origin **exactly** (including scheme, host, and port). For example:
- `https://localhost:8443` is a match.
- `http://localhost:8443` is **not** a match (different scheme).
- `https://localhost` is **not** a match (different port).
- `https://127.0.0.1:8443` is **not** a match (different host).

This plugin makes target origins explicit and provides helpers to generate correct project mappings.

---

## 🛠 Usage

### 1. Generating Playwright Projects with mTLS
In your `playwright.config.ts`, import the helpers to quickly map logical identities (`admin`, `user`, `unauthorized`) to your target browsers:

```typescript
import { defineConfig } from '@playwright/test';
import { createCertProject, getWebGLArgs, getMetadata, getArtifactPaths } from '@orieken/saturday-playwright-certs';

const baseURL = process.env.BASE_URL ?? 'https://localhost:8443';
const certificateRoot = process.env.CERT_ROOT ?? 'certs/generated';

// Generate dynamic run paths
const runTimestamp = process.env.PW_RUN_TIMESTAMP_UTC ?? new Date().toISOString().replace(/[:.]/g, '-');
const containerVariant = process.env.PW_CONTAINER_VARIANT ?? 'local';
const runId = process.env.PW_RUN_ID ?? `${containerVariant}-${runTimestamp}`;
const paths = getArtifactPaths(runId);

export default defineConfig({
  testDir: './tests',
  metadata: getMetadata({ baseURL, containerVariant, runId, runTimestamp }),
  reporter: [
    ['line'],
    ['html', { outputFolder: paths.htmlReport, open: 'never' }]
  ],
  outputDir: paths.testResults,
  use: {
    baseURL,
    ignoreHTTPSErrors: true,
    screenshot: 'only-on-failure',
    video: 'on',
    trace: 'retain-on-failure',
    launchOptions: {
      args: getWebGLArgs() // WebGL-headless helper args
    }
  },
  projects: [
    createCertProject('chrome', 'admin', { baseURL, certificateRoot }),
    createCertProject('chrome', 'user', { baseURL, certificateRoot }),
    createCertProject('chrome', 'unauthorized', { baseURL, certificateRoot }),
    createCertProject('msedge', 'admin', { baseURL, certificateRoot }),
    createCertProject('msedge', 'user', { baseURL, certificateRoot }),
    createCertProject('msedge', 'unauthorized', { baseURL, certificateRoot }),
  ]
});
```

### 2. Using Fixtures in Tests
To run tests with automated validation, use the extended `test` runner from the fixture module:

```typescript
import { test, expect } from '@orieken/saturday-playwright-certs/fixture';

test('verify mtls identity routing', async ({ page, certIdentity, verifyCertExists }) => {
  // Ensure certificate material exists for this user profile run
  if (certIdentity) {
    expect(verifyCertExists(certIdentity)).toBe(true);
  }

  await page.goto('/');

  if (certIdentity === 'admin') {
    await expect(page.locator('#admin-dashboard')).toBeVisible();
  } else if (certIdentity === 'user') {
    await expect(page.locator('#user-welcome')).toBeVisible();
    await expect(page.locator('#admin-dashboard')).not.toBeVisible();
  } else {
    // unauthorized/bad cert or anonymous path
    await expect(page.locator('#access-denied')).toBeVisible();
  }
});
```

---

## 🐳 Container Setup

### Secure Mounts (No Baked Secrets)
To prevent private keys from leaking into built Docker images, **never bake certificates into the Docker image**. Instead, mount them at runtime as read-only volumes (or Docker secrets):

```yaml
services:
  e2e-tests:
    image: my-saturday-tests:latest
    environment:
      CERT_ROOT: /run/certs
      BASE_URL: https://my-secure-site:8443
    volumes:
      - ./local-certs:/run/certs:ro
      - ./artifacts:/work/artifacts
```

### Version Enforcement
A dedicated verification script is included to prevent drift between container browsers and expected dependencies. Copy `.env.example` to `.env` and configure:

```bash
EXPECTED_NODE_MAJOR=24
EXPECTED_PLAYWRIGHT_VERSION=1.61.0
EXPECTED_GOOGLE_CHROME_VERSION=149.0.7827.155
EXPECTED_MICROSOFT_EDGE_VERSION=149.0.4022.69
```

Run the build script at container build time:
```dockerfile
# Inside Dockerfile
RUN bash node_modules/@orieken/saturday-playwright-certs/scripts/verify-build-versions.sh
```

### Virtual Framebuffers (Xvfb)
Branded Chrome & Edge require X11 display context for headed rendering (especially for WebGL heavy pages). By running inside our entrypoint script, you can execute headed tests headless:

```bash
# Set environment
PW_HEADED=true

# Container starts tests through the helper entrypoint
test-entrypoint.sh npx playwright test
```
This automatically initiates Xvfb virtual framebuffers behind the scenes inside the container.
